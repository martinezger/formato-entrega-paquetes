from setuptools import setup

setup(

    name="german_40425",
    version="1.0",
    description="",
    author= "German Martinez",
    author_email = "g@g.com",

    packages= ["la_entrega"],

)